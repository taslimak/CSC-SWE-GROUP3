from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name="index"),
    path('index.html', views.index, name="index"),
    path('prediction.html', views.prediction, name="prediction"),
    path('comparison.html', views.comparison, name="comparison"),
    path('gainers.html', views.gainers, name ="gainers"),
    path('losers.html', views.losers, name ='losers'),
    path('balance.html', views.balance, name ='balance'),
    path('historical.html', views.historical, name ='historical'),
    path('login.html', views.login, name="login"),
    path('register.html', views.register, name="register"),
    path('forgot-password.html', views.forgot_password, name="forgot-password"),
    
]