from django.shortcuts import render, HttpResponse
import pandas as pd
import yahoo_fin as yf
import ftplib, io, json, requests, requests_html, pymysql, sqlalchemy
from plotly.offline import plot
from plotly.graph_objs import Scatter
import pandas_datareader.data as web
from sqlalchemy import create_engine

import yahoo_fin.stock_info as si

import datetime as dt
import matplotlib.pyplot as plt
import urllib.request, json
import os
import numpy as np
import math
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler
import plotly.express as px
import plotly.graph_objects as go
from .models import Stock
from .forms import TickerForm
from .forms import StockForm

# Create your views here.
ticker="NFLX"
def index(request):

    return render(request,'app/index.html')

def prediction(request):
    if request.method == 'POST':
        form1 = TickerForm(request.POST)
        if form1.is_valid():
            df = si.get_data(ticker, start_date="01/01/2000", end_date="12/31/2020", interval="1d")
            df.reset_index(level=0, inplace=True)
            df.columns = ['Date', 'Open', 'High','Low','Close','Adclose','Volume','Ticker']
            
            #Get index len
            ilen = len(df.index)/2
            ilen = math.floor(ilen)


            # First calculate the mid prices from the highest and lowest
            high = df.loc[:,'High'].to_numpy()
            low = df.loc[:,'Low'].to_numpy()
            mid = (high+low)/2.0
            #set up to train data
            train = mid[:ilen]
            test = mid[ilen:]
            
            scaler = MinMaxScaler()
            train = train.reshape(-1,1)
            test = test.reshape(-1,1)

            # Train the Scaler with training data and smooth data
            smoothing_window_size = 2500
            for di in range(0,1000,smoothing_window_size):
                scaler.fit(train[di:di+smoothing_window_size,:])
                train[di:di+smoothing_window_size,:] = scaler.transform(train[di:di+smoothing_window_size,:])
            
            # exponential moving average smoothing
            #gives a smoother curve 
            EMA = 0.0
            G = 0.1
            for ti in range(ilen):
                EMA = G*train[ti] + (1-G)*EMA
                train[ti] = EMA

            #Prediction algo, uses standard average which is best to see for the following day
            all_mid_data = np.concatenate([train,test],axis=0)
            window_size = 30
            N = train.size
            avg_predictions = []
            avg_x = []
            mse_errors = []

            for pred_idx in range(window_size,N):

                if pred_idx >= N:
                    date = dt.datetime.strptime(k, '%Y-%m-%d').date() + dt.timedelta(days=1)
                else:
                    date = df.loc[pred_idx,'Date']

                avg_predictions.append(np.mean(train[pred_idx-window_size:pred_idx]))
                mse_errors.append((avg_predictions[-1]-train[pred_idx])**2)
                avg_x.append(date)

            print('MSE error for standard averaging: %.5f'%(0.5*np.mean(mse_errors)))
            
            dz = df.shape[0]

            

            fig = px.line(x=range(window_size,N), y=avg_predictions, title='Stock Prediction for ' + str(ticker))
            fig.update_layout(
            xaxis_title="Days",
            yaxis_title="Average Price",)
            plot_div = fig.show()
            
        return render(request,'app/prediction.html',{'form1': form1})
    else:
        form1 = TickerForm()
        return render(request,'app/prediction.html',{'form1': form1})

def comparison(request):
    if request.method == 'POST':
        form2 = TickerForm(request.POST)
        if form2.is_valid():
            
            df = si.get_data(ticker = request.POST['ticker'], start_date="01/01/2000", end_date="12/31/2020", interval="1d")
            df.reset_index(level=0, inplace=True)
            df.columns = ['Date', 'Open', 'High','Low','Close','Adclose','Volume','Ticker']
            
            #Get index len
            ilen = len(df.index)/2
            ilen = math.floor(ilen)


            # First calculate the mid prices from the highest and lowest
            high = df.loc[:,'High'].to_numpy()
            low = df.loc[:,'Low'].to_numpy()
            mid = (high+low)/2.0
            #set up to train data
            train = mid[:ilen]
            test = mid[ilen:]
            
            scaler = MinMaxScaler()
            train = train.reshape(-1,1)
            test = test.reshape(-1,1)

            # Train the Scaler with training data and smooth data
            smoothing_window_size = 2500
            for di in range(0,1000,smoothing_window_size):
                scaler.fit(train[di:di+smoothing_window_size,:])
                train[di:di+smoothing_window_size,:] = scaler.transform(train[di:di+smoothing_window_size,:])
            
            # exponential moving average smoothing
            #gives a smoother curve 
            EMA = 0.0
            G = 0.1
            for ti in range(ilen):
                EMA = G*train[ti] + (1-G)*EMA
                train[ti] = EMA

            #Prediction algo, uses standard average which is best to see for the following day
            all_mid_data = np.concatenate([train,test],axis=0)
            window_size = 30
            N = train.size
            avg_predictions = []
            avg_x = []
            mse_errors = []

            for pred_idx in range(window_size,N):

                if pred_idx >= N:
                    date = dt.datetime.strptime(k, '%Y-%m-%d').date() + dt.timedelta(days=1)
                else:
                    date = df.loc[pred_idx,'Date']

                avg_predictions.append(np.mean(train[pred_idx-window_size:pred_idx]))
                mse_errors.append((avg_predictions[-1]-train[pred_idx])**2)
                avg_x.append(date)
            out_mid_data = np.concatenate(all_mid_data[:2297]).ravel().tolist()
            print('MSE error for standard averaging: %.5f'%(0.5*np.mean(mse_errors)))

            fig = go.Figure()
            fig = go.Figure(data=go.Scatter(x=list(range(window_size,N)), y= avg_predictions[:2297], name="Prediction"))
            fig.add_trace(go.Scatter(x=list(range(2297)), y=out_mid_data, mode='lines',name='True'))
            fig.update_layout(
            xaxis_title="Days",
            yaxis_title="Average Price",)
            fig.show()
        return render(request,'app/comparison.html',{'form2': form2})
    else:
        form2 = TickerForm()
        return render(request,'app/comparison.html',{'form2': form2})

def login(request):
    if(request.method=="POST"):
        try:
            sqlEngine = create_engine('mysql+pymysql://softwarectw:professor1@stocksdb1.ci0tzktb6v7z.us-east-1.rds.amazonaws.com:3306/winnerslosers', pool_recycle=3600)

            user = request.POST.get('user', default=None)
            password = request.POST.get('pass', default=None)
            lookup = pd.read_sql("SELECT Password FROM Login WHERE Username='"+user+"'", con=sqlEngine)

            if(lookup["Password"][0] == password):
                return render(request, 'app/index.html')
            else:
                return render(request, 'app/login.html')
        except Exception as e:
            print(e)
            return render(request, 'app/login.html')
            
    else:
        return render(request, 'app/login.html')
    
    
            
def register(request):
    try:
	    sqlEngine = create_engine('mysql+pymysql://softwarectw:professor1@stocksdb1.ci0tzktb6v7z.us-east-1.rds.amazonaws.com:3306/winnerslosers', pool_recycle=3600)
	
	    user = request.POST.get('user', default=None)
	    email = request.POST.get('email', default=None)
	    password = request.POST.get('pass', default=None)

	    pd.read_sql("INSERT INTO Login values ('', '"+user+"', '"+password+"', '"+email+"' )", con=sqlEngine)
	
    except Exception as e:
	    print(e)
    return render(request,'app/register.html')

def forgot_password(request):
	return render(request,'app/forgot-password.html')

def gainers(request):
    gainers = si.get_day_gainers()
    df = pd.DataFrame(gainers)
    context = {'df': df.to_html()}
    return render(request, 'app/gainers.html', context)

# def gainers(request,*arg,**kargs):
#     gainers = si.get_day_gainers()
#     df = pd.DataFrame(gainers)
#     context = df.to_csv(r'gainers.csv', index = False, header=True)
#     return HttpResponse(context) 

def losers(request):
    losers = si.get_day_losers()
    df = pd.DataFrame(losers)
    context = {'df': df.to_html()}
    return render(request, 'app/losers.html', context)


def balance(request):
    if request.method == 'POST':
        form = TickerForm(request.POST)
        if form.is_valid():
            balanceSheet = si.get_data(ticker = request.POST['ticker'])
            df = pd.DataFrame(balanceSheet)
            context = {'df': df.to_html(), 'form': form}
    
            return render(request, 'app/balance.html', context)  

    else:      
        
        balanceSheet = si.get_balance_sheet(ticker="nflx")
        form = TickerForm()
    
        df = pd.DataFrame(balanceSheet)
        context = {'df': df.to_html(), 'form': form}
        return render(request, 'app/balance.html', context)
        
def historical(request):
    if request.method == 'POST':
        form = TickerForm(request.POST)
        if form.is_valid():
            
            companyData = si.get_data(ticker = request.POST['ticker'], start_date="01/01/2019" ,  end_date= "/01/2020", interval="1mo")
            df = pd.DataFrame(companyData)
            context = {'df': df.to_html(), 'form': form}
    
            return render(request, 'app/historical.html', context)  

    else:      
        
        companyData = si.get_data(ticker="nflx" , start_date="01/01/2019" ,  end_date= "01/01/2020", interval="1mo")
        form = TickerForm()
    
        df = pd.DataFrame(companyData)

        context = {'df': df.to_html(), 'form': form}
        return render(request, 'app/historical.html', context)

